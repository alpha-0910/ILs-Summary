各用語の意味
PB…自己ベスト(Personal Best)
WR…世界記録(World Record)
B-W…自己ベスト-世界記録(PB-WR)
MR…世界で自身の順位(My Rank)