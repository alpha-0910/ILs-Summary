PB…Personal Best
WR…World Record
B-W…PB-WR
MR…My Rank(in worldwide)